"""
GA4 Multi-Property Extractor -> SQL Server
DB: Digital_Impact_Reportes

Usage:
    python ga4_extractor_to_sql.py
"""

from __future__ import annotations

import json
import re
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, List

import pandas as pd
from google.analytics.data_v1beta import BetaAnalyticsDataClient
from google.analytics.data_v1beta.types import RunReportRequest, DateRange, Metric, Dimension
from google.oauth2 import service_account
from google.api_core.exceptions import (
    PermissionDenied,
    ResourceExhausted,
    ServiceUnavailable,
    InternalServerError,
    BadRequest,
)

import ga4_config as config
from ga4_db import (
    get_engine,
    test_connection,
    upsert_properties,
    start_run,
    finish_run,
    register_report_load,
    delete_existing,
    load_dataframe,
)


def log(level: str, message: str) -> None:
    print(f"[{level}] {message}")


def to_snake(name: str) -> str:
    explicit = {
        "yearMonth": "year_month",
        "eventName": "event_name",
        "sessionDefaultChannelGroup": "session_default_channel_group",
        "deviceCategory": "device_category",
        "totalUsers": "total_users",
        "activeUsers": "active_users",
        "purchaseRevenue": "purchase_revenue",
        "ecommercePurchases": "ecommerce_purchases",
        "averagePurchaseRevenue": "average_purchase_revenue",
        "itemsPurchased": "items_purchased",
        "engagementRate": "engagement_rate",
        "screenPageViewsPerSession": "screen_page_views_per_session",
        "cartToViewRate": "cart_to_view_rate",
        "purchaseToViewRate": "purchase_to_view_rate",
        "sessionKeyEventRate:purchase": "session_purchase_key_event_rate",
        "eventCount": "event_count",
        "itemsViewed": "items_viewed",
        "itemsAddedToCart": "items_added_to_cart",
        "itemRevenue": "item_revenue",
        "itemName": "item_name",
        "itemId": "item_id",
        "itemCategory": "item_category",
        "pagePath": "page_path",
        "pageTitle": "page_title",
        "screenPageViews": "screen_page_views",
        "landingPage": "landing_page",
    }
    if name in explicit:
        return explicit[name]
    s = name.replace(":", "_")
    s = re.sub(r"(?<!^)(?=[A-Z])", "_", s).lower()
    s = re.sub(r"[^a-z0-9_]+", "_", s)
    return s.strip("_")


def build_client() -> BetaAnalyticsDataClient:
    if not config.CREDENTIALS_FILE.exists():
        raise FileNotFoundError(f"No encontré credenciales GA4 en: {config.CREDENTIALS_FILE}")
    credentials = service_account.Credentials.from_service_account_file(
        config.CREDENTIALS_FILE,
        scopes=config.SCOPES,
    )
    return BetaAnalyticsDataClient(credentials=credentials)


def execute_report(
    client: BetaAnalyticsDataClient,
    property_id: str,
    report_name: str,
    dimensions: List[str],
    metrics: List[str],
    order_by_dim: str | None = None,
) -> pd.DataFrame:
    log("REPORT", f"{property_id} | {report_name}")
    all_rows: List[Dict[str, str]] = []
    offset = 0

    for attempt in range(config.MAX_RETRIES):
        try:
            while True:
                request = RunReportRequest(
                    property=f"properties/{property_id}",
                    dimensions=[Dimension(name=d) for d in dimensions],
                    metrics=[Metric(name=m) for m in metrics],
                    date_ranges=[DateRange(start_date=config.START_DATE, end_date=config.END_DATE)],
                    limit=config.PAGE_SIZE,
                    offset=offset,
                )

                response = client.run_report(request)
                rows = response.rows
                if not rows:
                    break

                for row in rows:
                    record = {}
                    for idx, dim in enumerate(dimensions):
                        record[dim] = row.dimension_values[idx].value
                    for idx, met in enumerate(metrics):
                        record[met] = row.metric_values[idx].value
                    all_rows.append(record)

                log("OK", f"{property_id} | {report_name} | offset={offset} | fetched={len(rows)}")
                if len(rows) < config.PAGE_SIZE:
                    break
                offset += config.PAGE_SIZE

            df = pd.DataFrame(all_rows)
            if order_by_dim and order_by_dim in df.columns and not df.empty:
                df = df.sort_values(by=order_by_dim).reset_index(drop=True)
            return df

        except PermissionDenied as e:
            log("CRITICAL", f"{property_id} | PERMISSION_DENIED: {e}")
            raise
        except BadRequest as e:
            log("CRITICAL", f"{property_id} | BAD_REQUEST: {e}")
            raise
        except (ResourceExhausted, ServiceUnavailable, InternalServerError) as e:
            wait_time = (attempt + 1) * config.RETRY_BASE_SECONDS
            log("WARN", f"{property_id} | retry {attempt+1}/{config.MAX_RETRIES} | wait={wait_time}s | {e}")
            time.sleep(wait_time)

    raise RuntimeError(f"No se pudo completar reporte {report_name} para property {property_id}")


def normalize_dataframe(df: pd.DataFrame, report: Dict, property_id: str, property_name: str, run_id: int) -> pd.DataFrame:
    if df.empty:
        # Crear columnas mínimas para que el flujo no reviente.
        return df

    df = df.rename(columns={c: to_snake(c) for c in df.columns})

    # Convertir métricas a numérico.
    for metric in report["metrics"]:
        col = to_snake(metric)
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")

    # Metadata común.
    df.insert(0, "property_name", property_name)
    df.insert(0, "property_id", property_id)
    df["run_id"] = run_id
    df["extracted_at"] = datetime.now()

    if report["grain"] == "monthly":
        if "year_month" not in df.columns:
            raise ValueError(f"Reporte mensual sin year_month: {report['name']}")
        df["year_month"] = df["year_month"].astype(str).str.slice(0, 6)
    else:
        df["start_date"] = config.START_DATE
        df["end_date"] = config.END_DATE

    # Evita nulos en campos de PK textual. GA4 a veces devuelve (not set), vacío o None.
    text_pk_cols = [
        "event_name", "session_default_channel_group", "device_category", "item_id", "item_category",
        "page_path", "landing_page",
    ]
    for col in text_pk_cols:
        if col in df.columns:
            df[col] = df[col].fillna("(not set)").astype(str)
            df.loc[df[col].str.strip() == "", col] = "(not set)"

    # item_id puede venir vacío; usa item_name como fallback parcial para no romper PK.
    if "item_id" in df.columns:
        fallback = df.get("item_name", pd.Series(["(not set)"] * len(df))).fillna("(not set)").astype(str)
        df.loc[df["item_id"].astype(str).str.strip() == "", "item_id"] = fallback

    # Orden estable: primero metadata, luego dimensiones/metricas.
    return df


def save_csv_backup(df: pd.DataFrame, property_name: str, report_name: str) -> None:
    if not config.SAVE_CSV_BACKUP or df.empty:
        return
    safe_brand = re.sub(r"[^a-zA-Z0-9_]+", "_", property_name.strip().lower()).strip("_")
    out_dir = config.OUTPUT_DIR / safe_brand
    out_dir.mkdir(parents=True, exist_ok=True)
    path = out_dir / f"{report_name}.csv"
    df.to_csv(path, index=False, encoding="utf-8-sig")


def main() -> None:
    log("START", "GA4 Multi-Property -> SQL Server")
    log("WINDOW", f"{config.START_DATE} -> {config.END_DATE}")
    log("PROPERTIES", ", ".join(config.PROPERTY_IDS_TO_RUN))

    engine = get_engine()
    test_connection(engine)
    upsert_properties(engine)

    client = build_client()
    run_id = start_run(engine, config.START_DATE, config.END_DATE, len(config.PROPERTY_IDS_TO_RUN))

    metadata = {
        "run_id": run_id,
        "start_date": config.START_DATE,
        "end_date": config.END_DATE,
        "generated_at": datetime.now().isoformat(),
        "properties": [],
    }

    successful_properties = 0
    failed_properties = 0
    global_errors = []

    for property_id in config.PROPERTY_IDS_TO_RUN:
        property_name = config.PROPERTY_INFO.get(property_id, property_id)
        property_status = {"property_id": property_id, "property_name": property_name, "reports": [], "status": "ok"}
        property_failed = False

        log("PROPERTY", f"{property_name} | {property_id}")

        for report in config.REPORTS:
            try:
                raw_df = execute_report(
                    client=client,
                    property_id=property_id,
                    report_name=report["name"],
                    dimensions=report["dimensions"],
                    metrics=report["metrics"],
                    order_by_dim=report.get("order_by_dim"),
                )
                df = normalize_dataframe(raw_df, report, property_id, property_name, run_id)
                save_csv_backup(df, property_name, report["name"])

                rows_loaded = 0
                deleted = 0
                if config.LOAD_TO_SQL and not df.empty:
                    deleted = delete_existing(
                        engine=engine,
                        table=report["table"],
                        grain=report["grain"],
                        property_id=property_id,
                        start_date=config.START_DATE,
                        end_date=config.END_DATE,
                        start_ym=config.START_YM,
                        end_ym=config.END_YM,
                    )
                    rows_loaded = load_dataframe(engine, df, report["table"])

                register_report_load(
                    engine, run_id, property_id, property_name, report["name"], report["table"], rows_loaded, "ok"
                )
                log("LOAD", f"{property_name} | {report['table']} | deleted={deleted} | inserted={rows_loaded}")

                property_status["reports"].append({
                    "report": report["name"],
                    "table": report["table"],
                    "rows_raw": len(raw_df),
                    "rows_loaded": rows_loaded,
                    "status": "ok",
                })

            except Exception as e:
                property_failed = True
                error_msg = str(e)
                log("ERROR", f"{property_name} | {report['name']} | {error_msg}")
                register_report_load(
                    engine, run_id, property_id, property_name, report["name"], report["table"], 0, "error", error_msg[:3900]
                )
                property_status["reports"].append({
                    "report": report["name"],
                    "table": report["table"],
                    "rows_loaded": 0,
                    "status": "error",
                    "error": error_msg,
                })
                # No rompemos todo; seguimos con el siguiente reporte/property.

        if property_failed:
            failed_properties += 1
            property_status["status"] = "partial_error"
            global_errors.append(f"{property_name}: revisar ga4_etl_report_loads")
        else:
            successful_properties += 1

        metadata["properties"].append(property_status)

    final_status = "success" if failed_properties == 0 else "partial_error"
    finish_run(
        engine,
        run_id,
        final_status,
        successful_properties,
        failed_properties,
        "; ".join(global_errors) if global_errors else None,
    )

    metadata_path = config.OUTPUT_DIR / f"execution_metadata_run_{run_id}.json"
    with open(metadata_path, "w", encoding="utf-8") as f:
        json.dump(metadata, f, indent=4, ensure_ascii=False, default=str)

    log("DONE", f"Finalizado. run_id={run_id} | status={final_status} | metadata={metadata_path}")


if __name__ == "__main__":
    main()
